import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Eraser,
  Paintbrush,
  Trash2,
  Undo,
  Redo,
  Palette,
  Circle,
  Square,
  Droplet
} from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DrawingToolsProps {
  color: string;
  brushSize: number;
  activeTool: string;
  onToolChange: (tool: string) => void;
  onColorChange: (color: string) => void;
  onBrushSizeChange: (size: number) => void;
  onClear: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  className?: string;
}

const PRESET_COLORS = [
  "#000000", // Black
  "#FFFFFF", // White
  "#FF0000", // Red
  "#00FF00", // Green
  "#0000FF", // Blue
  "#FFFF00", // Yellow
  "#FFA500", // Orange
  "#800080", // Purple
  "#FFC0CB", // Pink
  "#A52A2A", // Brown
];

const TOOLS = [
  { id: 'brush', icon: Paintbrush, label: 'Brush' },
  { id: 'eraser', icon: Eraser, label: 'Eraser' },
  { id: 'bucket', icon: Droplet, label: 'Fill' },
  { id: 'circle', icon: Circle, label: 'Circle' },
  { id: 'rectangle', icon: Square, label: 'Rectangle' },
];

export function DrawingTools({
  color,
  brushSize,
  activeTool,
  onToolChange,
  onColorChange,
  onBrushSizeChange,
  onClear,
  onUndo,
  onRedo,
  className = "",
}: DrawingToolsProps) {
  return (
    <div className={`flex flex-wrap items-center gap-4 p-2 bg-card rounded-lg ${className}`}>
      {/* Drawing Tools */}
      <div className="flex items-center gap-2">
        {TOOLS.map((tool) => {
          const Icon = tool.icon;
          return (
            <Button
              key={tool.id}
              variant={activeTool === tool.id ? "default" : "outline"}
              size="icon"
              onClick={() => onToolChange(tool.id)}
              title={tool.label}
            >
              <Icon className="h-4 w-4" />
            </Button>
          );
        })}
      </div>

      {/* History Controls */}
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={onUndo}
          disabled={!onUndo}
          title="Undo"
        >
          <Undo className="h-4 w-4" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          onClick={onRedo}
          disabled={!onRedo}
          title="Redo"
        >
          <Redo className="h-4 w-4" />
        </Button>
      </div>

      {/* Color Picker */}
      <Popover>
        <PopoverTrigger asChild>
          <Button 
            variant="outline" 
            size="icon"
            className="relative"
          >
            <Palette className="h-4 w-4" />
            <div 
              className="absolute bottom-1 right-1 w-2 h-2 rounded-full border"
              style={{ backgroundColor: color }}
            />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64">
          <div className="grid grid-cols-5 gap-2">
            {PRESET_COLORS.map((presetColor) => (
              <button
                key={presetColor}
                className={`w-8 h-8 rounded-lg border-2 ${
                  color === presetColor ? 'border-primary' : 'border-transparent'
                }`}
                style={{ backgroundColor: presetColor }}
                onClick={() => onColorChange(presetColor)}
                title={presetColor === "#FFFFFF" ? "White" : ""}
              />
            ))}
          </div>
          <div className="mt-4">
            <input
              type="color"
              value={color}
              onChange={(e) => onColorChange(e.target.value)}
              className="w-full h-8 cursor-pointer"
            />
          </div>
        </PopoverContent>
      </Popover>

      {/* Brush Size Slider */}
      <div className="flex items-center gap-4 flex-1">
        <Paintbrush className="h-4 w-4 text-muted-foreground" />
        <Slider
          value={[brushSize]}
          min={1}
          max={50}
          step={1}
          onValueChange={([value]) => onBrushSizeChange(value)}
          className="w-32"
        />
        <span className="text-sm text-muted-foreground w-8">
          {brushSize}px
        </span>
      </div>

      {/* Clear Canvas */}
      <Button
        variant="outline"
        size="icon"
        onClick={onClear}
        className="text-destructive"
        title="Clear canvas"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}