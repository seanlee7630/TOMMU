import { useRef, useEffect, useState } from "react";
import { DrawingTools } from "./DrawingTools";

interface CanvasProps {
  initialImage?: string;
  onSave: (imageData: string) => void;
  readOnly?: boolean;
}

export function Canvas({ initialImage, onSave, readOnly = false }: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tempCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);
  const [tempContext, setTempContext] = useState<CanvasRenderingContext2D | null>(null);
  const [color, setColor] = useState("#000000");
  const [brushSize, setBrushSize] = useState(5);
  const [lastX, setLastX] = useState(0);
  const [lastY, setLastY] = useState(0);
  const [history, setHistory] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(-1);
  const [activeTool, setActiveTool] = useState("brush");
  const [startX, setStartX] = useState(0);
  const [startY, setStartY] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas dimensions
    canvas.width = 800;
    canvas.height = 600;

    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    // Set basic drawing parameters
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;
    ctx.lineWidth = brushSize;
    setContext(ctx);

    // Create temporary canvas for shape preview
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return;

    tempCanvasRef.current = tempCanvas;
    setTempContext(tempCtx);

    // Load initial image if provided
    if (initialImage) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0);
        saveToHistory(canvas.toDataURL());
      };
      img.src = initialImage;
    } else {
      // Set white background
      ctx.fillStyle = "white";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      saveToHistory(canvas.toDataURL());
    }
  }, [initialImage]);

  useEffect(() => {
    if (context) {
      context.strokeStyle = activeTool === "eraser" ? "#FFFFFF" : color;
      context.lineWidth = brushSize;
      context.globalAlpha = activeTool === 'brush' ? 0.9 : 1; // Slightly transparent for better blending
    }
  }, [color, brushSize, context, activeTool]);

  const saveToHistory = (imageData: string) => {
    const newHistory = history.slice(0, currentStep + 1);
    newHistory.push(imageData);
    setHistory(newHistory);
    setCurrentStep(newHistory.length - 1);
  };

  const loadHistoryStep = (step: number) => {
    if (!context || !canvasRef.current) return;
    const img = new Image();
    img.onload = () => {
      context.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
      context.drawImage(img, 0, 0);
    };
    img.src = history[step];
    setCurrentStep(step);
  };

  const undo = () => {
    if (currentStep > 0) {
      loadHistoryStep(currentStep - 1);
    }
  };

  const redo = () => {
    if (currentStep < history.length - 1) {
      loadHistoryStep(currentStep + 1);
    }
  };

  const floodFill = (startX: number, startY: number, fillColor: string) => {
    if (!context || !canvasRef.current) return;

    const imageData = context.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
    const pixels = imageData.data;
    const width = canvasRef.current.width;
    const height = canvasRef.current.height;

    const startPos = (startY * width + startX) * 4;
    const targetR = pixels[startPos];
    const targetG = pixels[startPos + 1];
    const targetB = pixels[startPos + 2];
    const targetA = pixels[startPos + 3];

    const fillR = parseInt(fillColor.slice(1, 3), 16);
    const fillG = parseInt(fillColor.slice(3, 5), 16);
    const fillB = parseInt(fillColor.slice(5, 7), 16);

    // Tolerance for color matching
    const tolerance = 30;
    const matchesTarget = (pos: number) => {
      return Math.abs(pixels[pos] - targetR) <= tolerance &&
             Math.abs(pixels[pos + 1] - targetG) <= tolerance &&
             Math.abs(pixels[pos + 2] - targetB) <= tolerance &&
             Math.abs(pixels[pos + 3] - targetA) <= tolerance;
    };

    const setColor = (pos: number) => {
      pixels[pos] = fillR;
      pixels[pos + 1] = fillG;
      pixels[pos + 2] = fillB;
      pixels[pos + 3] = 255;
    };

    // Process pixels in a queue for better performance
    const queue: number[] = [startY * width + startX];
    const processed = new Set<number>();

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (processed.has(current)) continue;

      const x = current % width;
      const y = Math.floor(current / width);
      const pos = current * 4;

      if (x < 0 || x >= width || y < 0 || y >= height || !matchesTarget(pos)) {
        continue;
      }

      setColor(pos);
      processed.add(current);

      // Add adjacent pixels
      if (x > 0) queue.push(current - 1);         // Left
      if (x < width - 1) queue.push(current + 1); // Right
      if (y > 0) queue.push(current - width);     // Up
      if (y < height - 1) queue.push(current + width); // Down
    }

    context.putImageData(imageData, 0, 0);
  };

  const getCoordinates = (event: React.MouseEvent | React.TouchEvent | Touch) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    let clientX, clientY;
    if ('touches' in event) {
      clientX = event.touches[0].clientX;
      clientY = event.touches[0].clientY;
    } else if ('clientX' in event) {
      clientX = event.clientX;
      clientY = event.clientY;
    } else {
      clientX = event.clientX;
      clientY = event.clientY;
    }

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const drawShapePreview = (coords: { x: number; y: number }) => {
    if (!context || !canvasRef.current || !tempContext || !tempCanvasRef.current) return;

    // First copy the original canvas state to temp canvas
    tempContext.clearRect(0, 0, tempCanvasRef.current.width, tempCanvasRef.current.height);
    tempContext.drawImage(canvasRef.current, 0, 0);

    // Set drawing style
    tempContext.strokeStyle = activeTool === "eraser" ? "#FFFFFF" : color;
    tempContext.lineWidth = brushSize;
    tempContext.beginPath();

    if (activeTool === 'circle') {
      // Draw circle preview
      const radius = Math.sqrt(
        Math.pow(coords.x - startX, 2) + Math.pow(coords.y - startY, 2)
      );
      tempContext.arc(startX, startY, radius, 0, Math.PI * 2);
    } else if (activeTool === 'rectangle') {
      // Draw rectangle preview
      const width = coords.x - startX;
      const height = coords.y - startY;
      tempContext.rect(startX, startY, width, height);
    }

    tempContext.stroke();

    // Show the temp canvas as an overlay
    tempCanvasRef.current.style.position = 'absolute';
    tempCanvasRef.current.style.left = canvasRef.current.offsetLeft + 'px';
    tempCanvasRef.current.style.top = canvasRef.current.offsetTop + 'px';
    tempCanvasRef.current.style.width = canvasRef.current.offsetWidth + 'px';
    tempCanvasRef.current.style.height = canvasRef.current.offsetHeight + 'px';
    tempCanvasRef.current.style.pointerEvents = 'none';
    if (!tempCanvasRef.current.parentElement) {
      canvasRef.current.parentElement?.appendChild(tempCanvasRef.current);
    }
  };

  const finalizeShape = () => {
    if (!context || !canvasRef.current) return;

    // Remove temp canvas overlay
    tempCanvasRef.current?.parentElement?.removeChild(tempCanvasRef.current);

    // Draw the final shape
    context.beginPath();
    if (activeTool === 'circle') {
      const radius = Math.sqrt(
        Math.pow(lastX - startX, 2) + Math.pow(lastY - startY, 2)
      );
      context.arc(startX, startY, radius, 0, Math.PI * 2);
    } else if (activeTool === 'rectangle') {
      const width = lastX - startX;
      const height = lastY - startY;
      context.rect(startX, startY, width, height);
    }
    context.stroke();
    saveToHistory(canvasRef.current.toDataURL());
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (readOnly || !context) return;
    e.preventDefault();

    const coords = 'touches' in e ? getCoordinates(e.touches[0]) : getCoordinates(e);
    setIsDrawing(true);
    setStartX(coords.x);
    setStartY(coords.y);
    setLastX(coords.x);
    setLastY(coords.y);

    if (activeTool === 'bucket') {
      floodFill(Math.floor(coords.x), Math.floor(coords.y), color);
      saveToHistory(canvasRef.current!.toDataURL());
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || readOnly || !context || activeTool === 'bucket') return;
    e.preventDefault();

    const coords = 'touches' in e ? getCoordinates(e.touches[0]) : getCoordinates(e);

    if (activeTool === 'brush' || activeTool === 'eraser') {
      context.beginPath();
      context.moveTo(lastX, lastY);
      context.lineTo(coords.x, coords.y);
      context.stroke();
      setLastX(coords.x);
      setLastY(coords.y);
    } else if (activeTool === 'circle' || activeTool === 'rectangle') {
      setLastX(coords.x);
      setLastY(coords.y);
      drawShapePreview(coords);
    }
  };

  const stopDrawing = () => {
    if (isDrawing && canvasRef.current) {
      if (activeTool === 'circle' || activeTool === 'rectangle') {
        finalizeShape();
      } else if (activeTool !== 'bucket') {
        saveToHistory(canvasRef.current.toDataURL());
      }
    }
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    if (!context || !canvasRef.current) return;
    context.fillStyle = "white";
    context.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    saveToHistory(canvasRef.current.toDataURL());
  };

  const handleSave = () => {
    if (!canvasRef.current) return;
    const imageData = canvasRef.current.toDataURL();
    onSave(imageData);
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="border rounded-lg overflow-hidden bg-white">
        <canvas
          ref={canvasRef}
          style={{
            width: "100%",
            maxWidth: "800px",
            height: "auto",
            aspectRatio: "4/3",
            touchAction: "none"
          }}
          className="cursor-crosshair"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
      </div>

      {!readOnly && (
        <DrawingTools
          color={color}
          brushSize={brushSize}
          activeTool={activeTool}
          onToolChange={setActiveTool}
          onColorChange={setColor}
          onBrushSizeChange={setBrushSize}
          onClear={clearCanvas}
          onUndo={undo}
          onRedo={redo}
          className="mt-4"
        />
      )}

      {!readOnly && (
        <button
          onClick={handleSave}
          className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
        >
          Save Drawing
        </button>
      )}
    </div>
  );
}