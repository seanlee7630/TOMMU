import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { Canvas } from "@/components/Canvas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Create() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/create");
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [currentDrawing, setCurrentDrawing] = useState<any>(null);
  const isContinue = new URLSearchParams(window.location.search).get("mode") === "continue";

  useEffect(() => {
    if (isContinue) {
      fetchRandomDrawing();
    }
  }, [isContinue]);

  async function fetchRandomDrawing() {
    try {
      const res = await fetch("/api/drawings/random");
      if (!res.ok) throw new Error("No drawings available");
      const drawing = await res.json();
      setCurrentDrawing(drawing);
    } catch (error) {
      toast({
        title: "Error",
        description: "No incomplete drawings available. Try starting a new one!",
        variant: "destructive",
      });
      setLocation("/");
    }
  }

  async function handleSave(imageData: string) {
    try {
      if (isContinue && currentDrawing) {
        await apiRequest("PATCH", `/api/drawings/${currentDrawing.id}`, {
          imageData,
        });
      } else {
        if (!name.trim()) {
          toast({
            title: "Error",
            description: "Please enter a name for your drawing",
            variant: "destructive",
          });
          return;
        }

        await apiRequest("POST", "/api/drawings", {
          name,
          imageData,
        });
      }

      toast({
        title: "Success",
        description: "Drawing saved successfully!",
      });
      setLocation("/gallery");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save drawing",
        variant: "destructive",
      });
    }
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl md:text-3xl font-bold mb-8">
          {isContinue ? "Continue Drawing" : "Start New Drawing"}
        </h1>

        {!isContinue && (
          <div className="mb-6">
            <Input
              placeholder="Enter drawing name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="max-w-sm"
            />
          </div>
        )}

        {isContinue && currentDrawing && (
          <div className="mb-4">
            <h2 className="text-xl font-semibold mb-2">
              {currentDrawing.name}
            </h2>
            <p className="text-muted-foreground">
              You will be the {(currentDrawing.participants + 1)}th participant in this drawing chain
            </p>
          </div>
        )}

        <Canvas
          initialImage={currentDrawing?.imageData}
          onSave={handleSave}
        />

        <div className="mt-4">
          <Button variant="outline" onClick={() => setLocation("/")}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}