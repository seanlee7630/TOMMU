import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Palette, Users } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-8">
          Collaborative Drawing Chain
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center gap-4">
                <Palette className="w-12 h-12 text-primary" />
                <h2 className="text-2xl font-semibold">Start New Drawing</h2>
                <p className="text-muted-foreground">
                  Create a new drawing and let others continue your artwork
                </p>
                <Link href="/create">
                  <Button className="w-full">Create New Drawing</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center gap-4">
                <Users className="w-12 h-12 text-primary" />
                <h2 className="text-2xl font-semibold">Continue a Drawing</h2>
                <p className="text-muted-foreground">
                  Join an existing drawing chain and add your creative touch
                </p>
                <Link href="/create?mode=continue">
                  <Button className="w-full">Continue Drawing</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <Link href="/gallery">
            <Button variant="outline">View Completed Drawings</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}