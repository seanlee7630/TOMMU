import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThumbsUp, MessageSquare } from "lucide-react";
import { Canvas } from "@/components/Canvas";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Gallery() {
  const { toast } = useToast();
  const [selectedDrawing, setSelectedDrawing] = useState<number | null>(null);
  const [comment, setComment] = useState("");

  // WebSocket setup
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "DRAWING_UPDATED" || data.type === "LIKES_UPDATED" || data.type === "NEW_COMMENT") {
        // Refetch the drawings to update the UI
        drawingsQuery.refetch();
      }
    };

    return () => ws.close();
  }, []);

  const drawingsQuery = useQuery({
    queryKey: ["/api/drawings/completed"],
    refetchInterval: false,
  });

  const likeMutation = useMutation({
    mutationFn: async (drawingId: number) => {
      await apiRequest("POST", `/api/drawings/${drawingId}/like`, {});
    },
    onSuccess: () => {
      drawingsQuery.refetch();
    },
  });

  const commentMutation = useMutation({
    mutationFn: async ({ drawingId, content }: { drawingId: number; content: string }) => {
      await apiRequest("POST", "/api/comments", { drawingId, content });
    },
    onSuccess: () => {
      setComment("");
      drawingsQuery.refetch();
      toast({
        title: "Success",
        description: "Comment added successfully",
      });
    },
  });

  const handleComment = (drawingId: number) => {
    if (!comment.trim()) {
      toast({
        title: "Error",
        description: "Please enter a comment",
        variant: "destructive",
      });
      return;
    }

    commentMutation.mutate({ drawingId, content: comment });
  };

  if (drawingsQuery.isLoading) {
    return <div className="p-4 md:p-8 text-center">Loading...</div>;
  }

  if (drawingsQuery.isError) {
    return <div className="p-4 md:p-8 text-center">Error loading gallery</div>;
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-8">Completed Drawings Gallery</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {drawingsQuery.data?.map((drawing: any) => (
          <Card key={drawing.id} className="overflow-hidden">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{drawing.name}</h2>
              <Canvas
                initialImage={drawing.imageData}
                onSave={() => {}}
                readOnly
              />
            </CardContent>

            <CardFooter className="flex flex-col gap-4 p-4">
              <div className="flex justify-between w-full">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => likeMutation.mutate(drawing.id)}
                >
                  <ThumbsUp className="w-4 h-4 mr-2" />
                  {drawing.likes || 0} Likes
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedDrawing(drawing.id === selectedDrawing ? null : drawing.id)}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Comments
                </Button>
              </div>

              {selectedDrawing === drawing.id && (
                <div className="w-full">
                  <div className="flex gap-2 mb-2">
                    <Input
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Add a comment..."
                    />
                    <Button onClick={() => handleComment(drawing.id)}>
                      Send
                    </Button>
                  </div>

                  <div className="max-h-40 overflow-y-auto">
                    {drawing.comments?.map((comment: any) => (
                      <div key={comment.id} className="text-sm p-2 border-b">
                        <p className="text-muted-foreground">
                          {new Date(comment.createdAt).toLocaleDateString()}
                        </p>
                        <p>{comment.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}