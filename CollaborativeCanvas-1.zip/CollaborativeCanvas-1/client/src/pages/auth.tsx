import { AuthForm } from "@/components/AuthForm";
import { Link } from "wouter";

interface AuthProps {
  mode: "login" | "register";
}

export default function Auth({ mode }: AuthProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4 flex flex-col items-center justify-center">
      <AuthForm mode={mode} />
      
      <p className="mt-4 text-sm text-muted-foreground">
        {mode === "login" ? (
          <>
            Don't have an account?{" "}
            <Link href="/register" className="text-primary hover:underline">
              Register
            </Link>
          </>
        ) : (
          <>
            Already have an account?{" "}
            <Link href="/login" className="text-primary hover:underline">
              Login
            </Link>
          </>
        )}
      </p>
    </div>
  );
}
