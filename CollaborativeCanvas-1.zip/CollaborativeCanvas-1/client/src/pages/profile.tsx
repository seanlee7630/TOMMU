import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Canvas } from "@/components/Canvas";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { toast } = useToast();

  const userQuery = useQuery({
    queryKey: ["/api/auth/me"],
  });

  const drawingsQuery = useQuery({
    queryKey: ["/api/drawings/user"],
    enabled: !!userQuery.data,
  });

  if (userQuery.isLoading || drawingsQuery.isLoading) {
    return <div className="p-4 text-center">Loading...</div>;
  }

  if (!userQuery.data) {
    return <div className="p-4 text-center">Please log in to view your gallery</div>;
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-8">
        My Gallery
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {drawingsQuery.data?.map((drawing: any) => (
          <Card key={drawing.id} className="overflow-hidden">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{drawing.name}</h2>
              <Canvas
                initialImage={drawing.imageData}
                onSave={() => {}}
                readOnly
              />
              <p className="text-sm text-muted-foreground mt-2">
                Created: {new Date(drawing.createdAt).toLocaleDateString()}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
