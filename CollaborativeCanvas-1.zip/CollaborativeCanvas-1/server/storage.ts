import { drawings, type Drawing, type InsertDrawing, 
         comments, type Comment, type InsertComment, 
         likes, users, type User, type InsertUser } from "@shared/schema";
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);
const db = drizzle(client);

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserDrawings(userId: number): Promise<Drawing[]>;

  // Drawing operations
  createDrawing(drawing: InsertDrawing): Promise<Drawing>;
  getDrawing(id: number): Promise<Drawing | undefined>;
  updateDrawing(id: number, imageData: string): Promise<Drawing>;
  getRandomIncompleteDrawing(): Promise<Drawing | undefined>;
  getCompletedDrawings(): Promise<Drawing[]>;

  // Comment operations
  addComment(comment: InsertComment): Promise<Comment>;
  getComments(drawingId: number): Promise<Comment[]>;

  // Like operations
  incrementLikes(drawingId: number, userId: number): Promise<void>;
  getLikes(drawingId: number): Promise<number>;
}

export class PostgresStorage implements IStorage {
  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserDrawings(userId: number): Promise<Drawing[]> {
    return db.select().from(drawings).where(eq(drawings.userId, userId));
  }

  async createDrawing(drawing: InsertDrawing): Promise<Drawing> {
    const [newDrawing] = await db.insert(drawings).values(drawing).returning();
    return newDrawing;
  }

  async getDrawing(id: number): Promise<Drawing | undefined> {
    const [drawing] = await db.select().from(drawings).where(eq(drawings.id, id));
    return drawing;
  }

  async updateDrawing(id: number, imageData: string): Promise<Drawing> {
    const [drawing] = await db.select().from(drawings).where(eq(drawings.id, id));
    if (!drawing) throw new Error("Drawing not found");

    const participants = drawing.participants + 1;
    const isComplete = participants >= 100;

    const [updatedDrawing] = await db
      .update(drawings)
      .set({ imageData, participants, isComplete })
      .where(eq(drawings.id, id))
      .returning();

    return updatedDrawing;
  }

  async getRandomIncompleteDrawing(): Promise<Drawing | undefined> {
    const incompleteDrawings = await db
      .select()
      .from(drawings)
      .where(eq(drawings.isComplete, false));

    if (incompleteDrawings.length === 0) return undefined;

    const randomIndex = Math.floor(Math.random() * incompleteDrawings.length);
    return incompleteDrawings[randomIndex];
  }

  async getCompletedDrawings(): Promise<Drawing[]> {
    return db
      .select()
      .from(drawings)
      .where(eq(drawings.isComplete, true))
      .orderBy(drawings.createdAt);
  }

  async addComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  async getComments(drawingId: number): Promise<Comment[]> {
    return db
      .select()
      .from(comments)
      .where(eq(comments.drawingId, drawingId))
      .orderBy(comments.createdAt);
  }

  async incrementLikes(drawingId: number, userId: number): Promise<void> {
    const [existingLike] = await db
      .select()
      .from(likes)
      .where(eq(likes.drawingId, drawingId))
      .where(eq(likes.userId, userId));

    if (!existingLike) {
      await db.insert(likes).values({
        drawingId,
        userId,
        count: 1
      });
    }
  }

  async getLikes(drawingId: number): Promise<number> {
    const likes = await db
      .select()
      .from(likes)
      .where(eq(likes.drawingId, drawingId));

    return likes.length;
  }
}

export const storage = new PostgresStorage();