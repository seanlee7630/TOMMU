import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertDrawingSchema, insertCommentSchema, insertUserSchema } from "@shared/schema";
import session from "express-session";
import { z } from "zod";
import bcrypt from "bcryptjs";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "secret",
      resave: false,
      saveUninitialized: false,
    })
  );

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const hashedPassword = await bcrypt.hash(data.password, 10);
      const user = await storage.createUser({
        ...data,
        password: hashedPassword,
      });
      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);

      if (!user || !await bcrypt.compare(data.password, user.password)) {
        res.status(401).json({ error: "Invalid credentials" });
        return;
      }

      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    const user = await storage.getUser(req.session.userId!);
    if (!user) {
      res.status(401).json({ error: "User not found" });
      return;
    }
    res.json({ id: user.id, username: user.username });
  });

  // Drawing routes
  app.post("/api/drawings", requireAuth, async (req, res) => {
    try {
      const data = insertDrawingSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const drawing = await storage.createDrawing(data);
      res.json(drawing);
    } catch (error) {
      res.status(400).json({ error: "Invalid drawing data" });
    }
  });

  app.get("/api/drawings/user", requireAuth, async (req, res) => {
    const drawings = await storage.getUserDrawings(req.session.userId!);
    res.json(drawings);
  });

  app.get("/api/drawings/random", async (req, res) => {
    const drawing = await storage.getRandomIncompleteDrawing();
    if (!drawing) {
      res.status(404).json({ error: "No incomplete drawings available" });
      return;
    }
    res.json(drawing);
  });

  app.get("/api/drawings/completed", async (req, res) => {
    const drawings = await storage.getCompletedDrawings();
    res.json(drawings);
  });

  app.patch("/api/drawings/:id", requireAuth, async (req, res) => {
    const { id } = req.params;
    const { imageData } = req.body;

    try {
      const drawing = await storage.updateDrawing(parseInt(id), imageData);

      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ type: "DRAWING_UPDATED", drawing }));
        }
      });

      res.json(drawing);
    } catch (error) {
      res.status(404).json({ error: "Drawing not found" });
    }
  });

  // Comments
  app.post("/api/comments", requireAuth, async (req, res) => {
    try {
      const data = insertCommentSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      const comment = await storage.addComment(data);

      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ 
            type: "NEW_COMMENT", 
            drawingId: data.drawingId,
            comment 
          }));
        }
      });

      res.json(comment);
    } catch (error) {
      res.status(400).json({ error: "Invalid comment data" });
    }
  });

  app.get("/api/drawings/:id/comments", async (req, res) => {
    const { id } = req.params;
    const comments = await storage.getComments(parseInt(id));
    res.json(comments);
  });

  // Likes
  app.post("/api/drawings/:id/like", requireAuth, async (req, res) => {
    const { id } = req.params;
    await storage.incrementLikes(parseInt(id), req.session.userId!);
    const likes = await storage.getLikes(parseInt(id));

    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ 
          type: "LIKES_UPDATED", 
          drawingId: parseInt(id),
          likes 
        }));
      }
    });

    res.json({ likes });
  });

  app.get("/api/drawings/:id/likes", async (req, res) => {
    const { id } = req.params;
    const likes = await storage.getLikes(parseInt(id));
    res.json({ likes });
  });

  return httpServer;
}